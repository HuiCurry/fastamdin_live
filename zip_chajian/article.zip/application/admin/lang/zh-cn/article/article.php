<?php

return [
    'Id'                      => '主键',
    'Type'                    => '栏目类型',
    'Title'                   => '标题',
    'Class_id'                => '分类',
    'Content'                 => '内容',
    'Describe'                => '描述',
    'Image'                   => '封面',
    'Num'                     => '点击量',
    'Weigh'                   => '权重',
    'Admin_id'                => '添加人id',
    'Createtime'              => '添加时间',
    'Updatetime'              => '修改时间',
    'Admin.nickname'          => '昵称',
    'Articleclass.class_name' => '分类名称',
    'News'                    => "新闻",
    'Example'                 => "案例"
];
