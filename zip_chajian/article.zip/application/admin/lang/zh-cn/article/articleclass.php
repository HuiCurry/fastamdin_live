<?php

return [
    'Id'             => '主键',
    'Type'           => '栏目类型',
    'Class_name'     => '分类名称',
    'Admin_id'       => '添加人id',
    'Is_enable'      => '是否启用',
    'Weigh'          => '权重',
    'Createtime'     => '添加时间',
    'Updatetime'     => '修改时间',
    'Admin.nickname' => '昵称',
    'News'           => "新闻",
    'Example'        => "案例",
    'Is_notice 1'    => '不是',
    'Is_notice 2'    => '是',
    'Is_enable 1'    => '启用',
    'Is_enable 2'    => '不启用',
];
