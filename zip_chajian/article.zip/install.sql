CREATE TABLE `__PREFIX__article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目类型',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `class_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `content` text COMMENT '内容',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面url',
  `num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击量',
  `weigh` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '添加人id',
  `createtime` int(11) unsigned DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(11) unsigned DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `class_id` (`class_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';

CREATE TABLE `__PREFIX__article_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目类型',
  `class_name` varchar(20) NOT NULL DEFAULT '' COMMENT '分类名称',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加人id',
  `is_enable` tinyint(3) NOT NULL DEFAULT '1' COMMENT '是否启用:1=启用;2=不启用',
  `weigh` int(11) unsigned DEFAULT '0' COMMENT '权重',
  `createtime` int(11) unsigned DEFAULT NULL COMMENT '添加时间',
  `updatetime` int(11) unsigned DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文章分类表';