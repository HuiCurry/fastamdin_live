<?php
namespace addons\Article;

use app\common\library\Menu;
use think\Addons;

/**
 * 新闻管理
 */
class Article extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'article',
                'title'   => '文章管理',
                'icon'    => 'fa fa-magic',
                'sublist' => [
                    [
                        'name'    => 'article/article',
                        'title'   => '文章列表',
                        'icon'    => 'fa fa-circle-o',
                        'sublist' => [
                            ['name' => 'article/article/index', 'title' => '查看'],
                            ['name' => 'article/article/add', 'title' => '添加'],
                            ['name' => 'article/article/edit', 'title' => '修改'],
                            ['name' => 'article/article/del', 'title' => '删除'],
                        ]
                    ],
                    [
                        'name'    => 'article/articleclass',
                        'title'   => '文章分类',
                        'icon'    => 'fa fa-circle-o',
                        'sublist' => [
                            ['name' => 'article/articleclass/index', 'title' => '查看'],
                            ['name' => 'article/articleclass/add', 'title' => '添加'],
                            ['name' => 'article/articleclass/edit', 'title' => '修改'],
                            ['name' => 'article/articleclass/del', 'title' => '删除'],
                        ]
                    ]
                ]
            ]
        ];
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        Menu::delete('article');
        return true;
    }

}
