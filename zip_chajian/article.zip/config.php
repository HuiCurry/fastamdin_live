<?php

return array (
  0 => 
  array (
    'name' => 'type',
    'title' => '栏目类型',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'news' => '新闻',
      'example' => '案例',
    ),
    'rule' => '',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
