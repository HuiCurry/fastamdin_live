
require.config({
    paths: {
        'layui': 'https://www.layuicdn.com/layui/layui',
    },
    shim: {
        'layui': {
            deps: ['css!https://www.layuicdn.com/layui/css/layui.css'],
        }
    }
});
require(['layui'], function(undefined){
    layui.use('colorpicker', function(){
        var $ = layui.$
            ,colorpicker = layui.colorpicker;
        var si= 0;
        $('.colorpicker').each(function (i) {
            var selfObj = $(this);
            selfObj.css({width:(selfObj.width()-20)+'px'});
            si++;
            selfObj.after('<div class="layui-inline" style="float: right;width: 31px">\n' +
                '                        <div class="colorpicker'+si+'"></div>\n' +
                '                    </div>');
            //表单赋值
            colorpicker.render({
                elem: '.colorpicker'+si
                ,color: selfObj.val()
                ,done: function(color){
                    selfObj.val(color);
                }
            });
        });

    });
});