<?php

namespace app\admin\model;

use addons\alivideo\library\Upload;
use think\Exception;
use think\Log;
use think\Model;


class Huivideo extends Model
{





    // 表名
    protected $name = 'hui_video';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
    ];

    protected static function init()
    {
        self::beforeDelete(function ($row) {
            try{
                Upload::instance()->deleteVideos($row['video_id']);
            }catch (Exception $exception){
            }
        });
    }



}
