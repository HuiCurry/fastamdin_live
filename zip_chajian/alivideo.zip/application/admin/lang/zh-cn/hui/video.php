<?php

return [
    'Title'      => '视频标题',
    'Cover'      => '视频封面',
    'Video_url'  => '视频播放地址',
    'Video_id'   => '视频ID',
    'Is_upload'  => '是否上传完成 0 否  1 是',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Filesize'   => '文件大小',
    'Time'       => '视频时长'
];
