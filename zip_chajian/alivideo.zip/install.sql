CREATE TABLE `__PREFIX__hui_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '视频标题',
  `cover` varchar(255) NOT NULL DEFAULT '' COMMENT '视频封面',
  `video_url` varchar(500) NOT NULL DEFAULT '' COMMENT '视频播放地址',
  `video_id` char(50) NOT NULL DEFAULT '' COMMENT '视频ID',
  `is_upload` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否上传完成 0 否  1 是',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `filesize` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '视频时长',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='视频表';