<?php
namespace addons\alivideo\library;
include_once ADDON_PATH.'alivideo/library/aliyun-php-sdk/aliyun-php-sdk-core/Config.php';

use think\Exception;
use \vod\Request\V20170321 as vod;
/**
 * 视频上传
 */
class Upload
{
    protected $regionId = 'cn-shanghai';

    protected static $instance;

    protected $client;

    public function __construct($option = [])
    {
        $config = get_addon_config('alivideo');

        $regionId = $option['regionId']??$this->regionId;
        $accessKeyId = $option['accessKeyId']??$config['accessKeyId'];
        $accessKeySecret = $option['accessKeySecret']??$config['accessKeySecret'];
        $profile = \DefaultProfile::getProfile($regionId, $accessKeyId, $accessKeySecret);

        $this->client = new \DefaultAcsClient($profile);
    }

    /**
     * 单例
     * instance
     * @param array $options
     * @return Upload
     * Date:2019/12/27 17:05
     * CreateAuthor:Hui-Curry
     */
    public static function instance($options = [])
    {
        if (is_null(self::$instance)) {
            self::$instance = new static($options);
        }
        return self::$instance;
    }

    // 获取视频上传地址和凭证
    // $data = [
        //'setTitle'=>'视频标题(必填参数)',
        //'setFileName'=>'视频源文件名称，必须包含扩展名(必填参数)',
        //'setDescription'=>'视频源文件描述(可选)',
        //'setCoverURL'=>'自定义视频封面(可选)',
        //'setTags'=>' 视频标签，多个用逗号分隔(可选)'

        //'setVideoId'=>'视频video_id (修改参数时添加此ID)'
    //]
    public function createUploadVideo($data) {

        $request =  isset($data['setVideoId']) ? new vod\UpdateVideoInfoRequest() : new vod\CreateUploadVideoRequest();

        if(empty($data)){
            return false;
        }else{
            foreach ($data as $k => $v){
                $request->$k($v);
            }
        }

        return $this->getAcsResponse($request);
    }

    /**
     * deleteVideos
     * @param $videoIds // 支持批量删除视频；videoIds为传入的视频ID列表，多个用逗号分隔
     * @return mixed
     * Date:2019/12/27 17:27
     * CreateAuthor:Hui-Curry
     */
    public function deleteVideos($videoIds) {
        try{
            $request = new vod\DeleteVideoRequest();

            $request->setVideoIds($videoIds);
            $request->setAcceptFormat('JSON');

            return $this->getAcsResponse($request);
        }catch (\ServerException $exception){
            throw new Exception($exception->getMessage());
        }
    }
    // 刷新上传凭证
    public function refreshUploadVideo($videoId) {

        $request = new vod\RefreshUploadVideoRequest();
        $request->setVideoId($videoId);

        return $this->getAcsResponse($request);
    }

    /**
     * 获取播放凭证
     * getPlayAuth
     * @param $videoId
     * @return mixed|\SimpleXMLElement
     * Date:2019/12/27 17:32
     * CreateAuthor:Hui-Curry
     */
    public function getPlayAuth($videoId) {

        $request = new vod\GetVideoPlayAuthRequest();

        $request->setVideoId($videoId);
        $request->setAuthInfoTimeout(3600);  // 播放凭证过期时间，默认为100秒，取值范围100~3600；注意：播放凭证用来传给播放器自动换取播放地址，凭证过期时间不是播放地址的过期时间
        $request->setAcceptFormat('JSON');

        return $this->getAcsResponse($request);
    }

    /**
     *获取视频播放详情
     */
    public function getVideoInfo($videoId)
    {
        $request = new vod\GetPlayInfoRequest();
        $request->setVideoId($videoId);
        $request->setAuthTimeout(3600 * 24);
        $request->setAcceptFormat('JSON');
        return $this->getAcsResponse($request);
    }

    private function getAcsResponse($request){
        return $this->client->getAcsResponse($request);
    }
}
