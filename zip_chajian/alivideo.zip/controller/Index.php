<?php

namespace addons\alivideo\controller;

use addons\alivideo\library\Upload;
use app\admin\model\Huivideo;
use think\addons\Controller;
use think\Config;
use think\Exception;
use think\Hook;
use think\Log;
use think\Request;

/**
 * 阿里云视频点播
 *
 */
class Index extends Controller
{

    protected $model = null;

    public function _initialize()
    {
        // 语言检测
//        $lang = strip_tags($this->request->langset());
        $site = Config::get("site");
        $upload = \app\common\model\Config::upload();
        // 上传信息配置后
        Hook::listen("upload_config_init", $upload);
        // 配置信息
        $config = [
            'site'           => array_intersect_key($site, array_flip(['name', 'cdnurl', 'version', 'timezone', 'languages'])),
            'upload'         => $upload,
            'modulename'     => 'addons',
            'controllername' => 'index',
            'actionname'     => $this->request->action(),
            'jsname'         => 'alivideo',
            'moduleurl'      => rtrim(url("/admin", '', false), '/'),
            'language'       => ''
        ];
        $config = array_merge($config, Config::get("view_replace_str"));

        Config::set('upload', array_merge(Config::get('upload'), $upload));
        // 配置信息后
        Hook::listen("config_init", $config);

        $this->view->assign('jsconfig', $config);
        $this->view->assign('site', $site);

        parent::_initialize();
    }

    public function index()
    {
        return $this->view->fetch();
    }

    public function upload()
    {
        $param = $this->request->param();
        $row = [];
        $row['title'] = $param['title'];
        $row['cover'] = $param['cover'];

        $this->assign('row',$row);
        return $this->view->fetch();
    }

    public function getUploadAuth(){
        $param = $this->request->param();
        if(isset($param['cover']) && (strpos('http://',$param['cover']) || strpos('https://',$param['cover']))){
            $param['cover'] = $this->request->domain().$param['cover'];
        }
        //file_name:temp,title:title,cover:cover
        $data = [
            'setTitle'=>$param['title'],
            'setFileName'=>$param['file_name'],
            'setCoverURL'=>$param['cover']
        ];
        $uploadAuth = Upload::instance()->createUploadVideo($data);
        $this->success('ok','',['UploadAddress'=>$uploadAuth->UploadAddress,'VideoId'=>$uploadAuth->VideoId,'UploadAuth'=>$uploadAuth->UploadAuth]);
    }

    public function uploadSuccess(){
        try{
            $param = $this->request->param();
            $row['video_id'] = $param['VideoId'];
            $row['is_upload'] = 1;
            $info = Upload::instance()->getVideoInfo($param['VideoId']);

            $info = $this->object_array($info);

            $row['video_url'] = $info['PlayInfoList']['PlayInfo'][0]['PlayURL'];
            $row['filesize'] = $info['PlayInfoList']['PlayInfo'][0]['Size'];
            $row['cover'] = $info['VideoBase']['CoverURL'];
            $row['title'] = $info['VideoBase']['Title'];

            $rows = Huivideo::create($row);
            $row['id'] = $rows->id;
            $this->success('','',$row);
        }catch (Exception $exception){
            $this->error($exception->getMessage());
        }

    }

    protected function object_array($array) {
        if(is_object($array)) {
            $array = (array)$array;
        }
        if(is_array($array)) {
            foreach($array as $key=>$value) {
                $array[$key] = $this->object_array($value);
            }
        }
        return $array;
    }

    public function getVideoInfo()
    {
        $id = $this->request->param('id');
        if($id){
            $vidoeInfo = Huivideo::get($id);
            if($vidoeInfo){
                $this->success('ok','',$vidoeInfo);
            }
        }
        $this->error('视频不存在。');
    }

    public static function getPlayAuth(){}

}