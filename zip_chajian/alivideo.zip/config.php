<?php

return array (
  0 => 
  array (
    'name' => 'accessKeyId',
    'title' => '视频点播ID',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'LTAImGpTMGrXsUxK',
    'rule' => 'require',
    'msg' => '',
    'tip' => '视频点播配置ID',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'accessKeySecret',
    'title' => '视频点播Secret',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'FZF6sLKvu2LsOE4jZbaacKZRYFPovD',
    'rule' => 'require',
    'msg' => '',
    'tip' => '视频点播配置Secret',
    'ok' => '',
    'extend' => '',
  ),
);
