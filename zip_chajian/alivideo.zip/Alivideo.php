<?php

namespace addons\alivideo;

use app\common\library\Menu;
use think\Addons;
use think\Exception;

/**
 * 阿里云视频点播插件
 */
class Alivideo extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'alivideo',
                'title'   => '视频管理',
                'icon'    => 'fa fa-magic',
                'sublist' => [
                    [
                        'name'    => 'hui/video',
                        'title'   => '视频列表',
                        'icon'    => 'fa fa-circle-o',
                        'sublist' => [
                            ['name' => 'hui/video/index', 'title' => '查看'],
                            ['name' => 'hui/video/del', 'title' => '删除'],
                        ]
                    ]
                ]
            ]
        ];
        self::installCommon();
        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        self::uninstallCommon();
        Menu::delete('alivideo');
        return true;
    }

    /**
     * 发布common文件代码
     * installCommon
     * Date:2020/1/6 18:49
     * CreateAuthor:Hui-Curry
     */
    public static function installCommon(){
        $commonPath = APP_PATH . DS . 'admin' . DS . 'common.php';
        $putContentFile = ADDON_PATH . DS . 'alivideo' . DS . 'library' . DS . 'common.tpl';
        $yCommonContent = file_get_contents($commonPath);

        $regex = '/\/\*\*-start_build_huivideo-\*\*\/.*?\/\*\*-end_build_huivideo-\*\*\//is';
        preg_match($regex,$yCommonContent,$match);
        if ($handle = fopen($commonPath, 'w')) {
            if(empty($match)){
                $tpl = $yCommonContent."\r\n".file_get_contents($putContentFile);
            }else{
                $tpl = preg_replace($regex,file_get_contents($putContentFile),$yCommonContent);
            }
            fwrite($handle, $tpl);
            fclose($handle);
        } else {
            throw new Exception("文件没有写入权限");
        }

    }
    /**
     * 删除common文件中的代码
     * installCommon
     * Date:2020/1/6 18:49
     * CreateAuthor:Hui-Curry
     */
    public static function uninstallCommon(){
        $commonPath = APP_PATH . DS . 'admin' . DS . 'common.php';
        $yCommonContent = file_get_contents($commonPath);

        $regex = '/\/\*\*-start_build_huivideo-\*\*\/.*?\/\*\*-end_build_huivideo-\*\*\//is';
        preg_match($regex,$yCommonContent,$match);
        if ($handle = fopen($commonPath, 'w')) {
            if(!empty($match)){
                $tpl = preg_replace($regex,'',$yCommonContent);
            }
            fwrite($handle, $tpl);
            fclose($handle);
        } else {
            throw new Exception("文件没有写入权限");
        }

    }

}
