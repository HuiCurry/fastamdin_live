if ($('.alivideo', $('form[role="form"]')).length > 0) {

    function HuiAliVideo(aliVideoObj) {
        this.allowVideoAttr = [
            {'field':'imageField','notMsg':'请先上传封面','undefinedMsg':'请定义data-image-field封面字段','paramsField':'cover'},
            {'field':'titleField','notMmsg':'请先填写标题','undefinedMsg':'请定义data-title-field标题字段','paramsField':'title'}
        ];
        this.aliVideoClass = aliVideoObj;
        this.inputBoxId =  aliVideoObj.data("input-id");
        this.videoBox =  document.getElementById(this.inputBoxId).nextSibling;
        this.error = null;
        this.params = [];
    }
    HuiAliVideo.prototype = {
        constructor:HuiAliVideo,
        videoInit : function (id = null,url = null) {
            let that = this;
            if(id == null){
                id = $('#'+that.inputBoxId).val() ? $('#'+that.inputBoxId).val() : null;
            }
            if(id !== null){
                if(url){
                    that.videoBox.nextElementSibling.src = url;
                }else{
                    $.post('/addons/alivideo/index/getVideoInfo',{id:id},function (resData) {
                        if(resData.code == 1){
                            that.videoBox.nextElementSibling.src = resData.data.video_url;
                        }
                    });
                }

                document.getElementById(that.inputBoxId).value = id;
            }
        },
        validate : function () {
            let that = this;
            that.error = null;
            var data = that.aliVideoClass.data();
            that.params = [];
            console.log(that.allowVideoAttr);
            $(that.allowVideoAttr).each(function (i,v) {
                if (typeof data[v.field] !== 'undefined' && data[v.field] !== ''){
                    var value = $('#'+data[v.field]).val();
                    if (!value || value == '') {
                        that.error = v.notMsg;
                    }else{
                        that.params.push(v.paramsField+'='+value);
                    }
                }else{
                    that.error = v.undefinedMsg;
                }
            });
        },
        upload : function () {
            let that = this;
            that.validate();
            if(that.error !== null){
                Fast.api.msg(that.error,function(){});return false;
            }
            console.log(that.params);
            (parent ? parent : window).Fast.api.open('/addons/alivideo/index/upload?='+(that.params.length > 0 ? '&' + that.params.join('&') : ''), '上传视频', {
                callback: function (data) {
                    if (typeof data !== 'undefined') {
                        that.videoInit(data.id,data.video_url);
                    }
                }
            });
        },
        choose : function (url) {
            let that = this;
            (parent ? parent : window).Fast.api.open(url, '上传视频', {
                callback: function (data) {
                    if (typeof data !== 'undefined') {
                        that.videoInit(data.id,data.video_url);
                    }
                }
            });
        }
    };

    $('.alivideo').each(function () {
        var HuiAliVideoClass =  new HuiAliVideo($(this));
        HuiAliVideoClass.videoInit();
        //点击上传
        $(this).click(function () {
            HuiAliVideoClass.upload();
        });
        //点击选择
        $(this).parents('div').find('.alivideoChoose').click(function () {
            HuiAliVideoClass.choose($(this).attr('choose-url'));
        });
    });
}