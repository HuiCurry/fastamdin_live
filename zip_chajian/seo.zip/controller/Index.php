<?php

namespace addons\seo\controller;

use think\addons\Controller;

class Index extends Controller
{

    protected $layout = false;

    public function index()
    {
        return $this->view->fetch();
    }

}
