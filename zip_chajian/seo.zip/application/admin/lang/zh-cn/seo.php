<?php

return [
    'Id'              => '主键',
    'Seo_title'      => 'SEO标题',
    'Seo_keyword'     => 'SEO关键词',
    'Seo_description' => 'SEO描述',
    'Type'            => '类型：url ',
    'Link_type'       => 'url地址',
    'Create_time'     => '创建时间',
    'Update_time'     => '更新时间'
];
