<?php

namespace app\admin\model;

use think\Cache;
use think\Model;


class Seo extends Model
{


    // 表名
    protected $name = 'seo';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = true;

    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';

    // 追加属性
    protected $append = [];

    protected static $seoConfig = [];

    public function getSeoInfo($id = null,$url = null,$table=null,$defaultSeoInfo = []){
        $seoInfo = [];
        $where = [];
        self::$seoConfig = get_addon_config('seo');
        if(!empty($id)){
            $type = str_replace(config('database.prefix'),'',$table);
            $where = ['type'=>$type,'link_type'=>$id];
        }
        if(empty($where) && !empty($url)){
            $where = ['type'=>'url','link_type'=>$url];
        }
        if(!empty($where)) $seoInfo = self::createSeoCache($where);

        $seoInfo['seo_title'] = ($seoInfo['seo_title'] ?? ($defaultSeoInfo['seo_title']??self::$seoConfig['seo_title'])).'-'.self::$seoConfig['company'];
        $seoInfo['seo_keyword'] = $seoInfo['seo_keyword'] ??($defaultSeoInfo['seo_keyword']??self::$seoConfig['seo_keyword']);
        $seoInfo['seo_description'] = $seoInfo['seo_description'] ??($defaultSeoInfo['seo_description']??self::$seoConfig['seo_description']);
        return $seoInfo;
    }

    protected static function createSeoCache($where){
        $cache_name = md5(json_encode($where));
        $cacheTime = self::$seoConfig['cache_time'];
        if($cacheTime <= 0){
            $seoInfo = self::where($where)->find();
        }else{
            $seoInfo = Cache::get($cache_name);
            if(empty($seoInfo)){
                $seoInfo = self::where($where)->find();
                if(!empty($seoInfo)){
                    Cache::set($cache_name,$seoInfo,$cacheTime);
                }
            }
        }

        return $seoInfo;
    }
}
