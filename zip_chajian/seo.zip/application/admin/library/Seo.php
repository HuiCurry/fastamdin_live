<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/5/8
 * Time: 13:59
 */
namespace app\admin\library;
use think\Exception;

class Seo
{

    protected $error = '';

    protected static $model = '';
    protected static $table = '';
    protected static $pkValue = '';
    protected static $where = [];

    public function __construct($model,$pkValue){
        self::$model = $model;
        self::$table = $model->getTable();
        self::setPkValue($pkValue);
        self::$where = ['type'=>self::getTable('no_prefix'),'link_type'=>self::$pkValue];
    }

    protected static function getTable($type = 'prefix'){
        return $type == 'no_prefix' ? str_replace( config('database.prefix'),'',self::$table) : self::$table;
    }

    protected static function setPkValue($pkValue){
        self::$pkValue = $pkValue ?:\think\Db::query("select auto_increment from information_schema.`TABLES` where table_name='".self::getTable()."' and table_schema='".config('database.database')."'")[0]['auto_increment'];
    }

    public function save($seoArr){
        $saveWhere = [];

        if($info = Model('Seo')->where(self::$where)->find()){
            $saveWhere['id'] = $info['id'];
        }

        try{
            $arr = array_merge($seoArr,self::$where);
            Model('Seo')->save($arr,$saveWhere);
        }catch (Exception $exception){
            $this->error = $exception->getMessage();
            throw new Exception($exception->getMessage());
        }
    }

    public function del(){
        try{
            self::$where['link_type'] = ['in',self::$pkValue];
            Model('Seo')->where(self::$where)->delete();
        }catch (Exception $exception){
            $this->error = $exception->getMessage();
            throw new Exception($exception->getMessage());
        }
    }

    public function getSeo(){
        return Model('Seo')->where(self::$where)->find();
    }

    public function getError(){
        return $this->error;
    }

}