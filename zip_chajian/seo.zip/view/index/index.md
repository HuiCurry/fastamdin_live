## seo 安装
   ###1.把下列代码放入前台基类中。
路径（application/common/controller/Frontend.php）
```php
    /**
     * 获取SEO
     * getSeo
     * @param null $id      获取seo信息的ID
     * @param null $table   获取seo的表名
     * @param [] $defaultSeoInfo   默认seo信息
     */
    public function getSeo($id =null,$table = null,$defaultSeoInfo = []){
        $controllername = strtolower($this->request->controller());
        $actionname = strtolower($this->request->action());
        $path = $controllername.'/'.$actionname;
        $seoInfo = (new \app\admin\model\Seo())->getSeoInfo($id,$path,$table,$defaultSeoInfo);

        $this->assign('seoInfo',$seoInfo);
    }
```  
   代码放入之后，就可以调用他来分配seo了。
   
#####1.1 调用 默认的SEO，这里可以放入基类中
    
        $this->getSeo();

#####1.2 针对某个内容调用SEO
   
        $this->getSeo($newsInfo['id'],'news');//拿news举例

##### 1.3 前台页面 head 中加入：
```html
<title>{$seoInfo.seo_title}</title>
<meta name="keywords" content="{$seoInfo.seo_keyword}" />
<meta name="description" content="{$seoInfo.seo_description}" />
```


------------------------------------------------------------------------
## 后台

#####2 对应的  `添加` 和 `修改` 页添加下列代码：
 ```html
{include file="common/seo" /}
```
