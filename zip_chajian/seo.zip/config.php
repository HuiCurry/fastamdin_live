<?php

return array (
  0 => 
  array (
    'name' => 'seo_title',
    'title' => 'SEO标题',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'seo_keyword',
    'title' => 'SEO关键词',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'seo_description',
    'title' => 'SEO描述',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'cache_time',
    'title' => 'SEO缓冲时间',
    'type' => 'number',
    'content' => 
    array (
    ),
    'value' => '6000',
    'rule' => 'required',
    'msg' => '',
    'tip' => '0为不开启缓冲',
    'ok' => '',
    'extend' => '',
  ),
  4 => 
  array (
    'name' => 'company',
    'title' => 'SEO公司名称',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '',
    'rule' => 'required',
    'msg' => '',
    'tip' => '0为不开启缓冲',
    'ok' => '',
    'extend' => '',
  ),
);
