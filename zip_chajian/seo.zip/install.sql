CREATE TABLE `__PREFIX__seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `seo_title` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `seo_keyword` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `seo_description` varchar(1000) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型：url | 关联表名',
  `link_type` varchar(255) NOT NULL COMMENT 'url地址和关联id',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;