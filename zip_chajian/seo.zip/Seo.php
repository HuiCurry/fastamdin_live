<?php
namespace addons\seo;

use app\common\library\Menu;
use think\Addons;
use think\Exception;

/**
 * Seo
 */
class Seo extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        $menu = [
            [
                'name'    => 'seoset',
                'title'   => 'SEO管理',
                'icon'    => 'fa fa-magic',
                'sublist' => [
                    [
                        'name'    => 'seo',
                        'title'   => 'SEO设定管理',
                        'icon'    => 'fa fa-circle-o',
                        'sublist' => [
                            ['name' => 'seo/index', 'title' => '查看'],
                            ['name' => 'seo/add', 'title' => '添加'],
                            ['name' => 'seo/edit', 'title' => '修改'],
                            ['name' => 'seo/del', 'title' => '删除'],
                        ]
                    ]
                ]
            ]
        ];


        $path = APP_PATH. DS . 'admin' . DS . 'tags.php';
        $tags = include $path;
        if(!isset($tags['action_begin'])) $tags['action_begin'] = [];
        array_push($tags['action_begin'],'app\\admin\\behavior\\Seo');
        $tagstr = '<?php '."\r\n".'return '.var_export_short($tags).';';
        file_put_contents($path,$tagstr);

        self::installCommon();


        Menu::create($menu);
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        $path = APP_PATH. DS . 'admin' . DS . 'tags.php';
        $tags = include $path;
        if(isset($tags['action_begin'])){
            if($keys = array_keys($tags['action_begin'],'app\\admin\\behavior\\Seo')){
                unset($tags['action_begin'][$keys[0]]);
            }
        }
        $tagstr = '<?php '."\r\n".'return '.var_export_short($tags).';';
        file_put_contents($path,$tagstr);

        self::uninstallCommon();
        Menu::delete('seoset');
        return true;
    }


    /**
     * 发布文件代码
     * installCommon
     */
    public static function installCommon(){
        $commonPath = APP_PATH . DS . 'admin' . DS . 'library'  . DS . 'traits' . DS . 'Backend.php';
        $putContentFile = ADDON_PATH . DS . 'seo' . DS . 'library' . DS . 'Backend.tpl';
        $yCommonContent = file_get_contents($commonPath);

        $regex = '/\/\*\*-start_seo-\*\*\/.*?\/\*\*-start_seo-\*\*\//is';
        preg_match($regex,$yCommonContent,$match);
        if ($handle = fopen($commonPath, 'w')) {
            if(empty($match)){
                $tpl = rtrim(trim($yCommonContent),'}')."\r\n".file_get_contents($putContentFile)."\r\n".'}';
            }else{
                $tpl = preg_replace($regex,file_get_contents($putContentFile),$yCommonContent);
            }
            fwrite($handle, $tpl);
            fclose($handle);
        } else {
            throw new Exception("文件没有写入权限");
        }


        $seoPath = APP_PATH . DS . 'admin' . DS . 'behavior'. DS .'Seo.php';
        if(file_exists($seoPath)){
           unlink($seoPath);
        }
        $content = file_get_contents(ADDON_PATH . DS . 'seo' . DS . 'library' . DS .'Seo.tpl');
        $myfile = fopen($seoPath, "w") or die("Unable to open file!");
        fwrite($myfile, $content);
        fclose($myfile);

    }
    /**
     * 删除文件中的代码
     * uninstallCommon
     */
    public static function uninstallCommon(){
        $commonPath = APP_PATH . DS . 'admin' . DS . 'library' . DS . 'traits' . DS . 'Backend.php';
        $yCommonContent = file_get_contents($commonPath);

        $regex = '/\/\*\*-start_seo-\*\*\/.*?\/\*\*-start_seo-\*\*\//is';
        preg_match($regex,$yCommonContent,$match);
        if ($handle = fopen($commonPath, 'w')) {
            if(!empty($match)){
                $tpl = preg_replace($regex,'',$yCommonContent);
                fwrite($handle, $tpl);
            }
            fclose($handle);
        } else {
            throw new Exception("文件没有写入权限");
        }

        $seoPath = APP_PATH . DS . 'admin' . DS . 'behavior'. DS .'Seo.php';
        if(file_exists($seoPath)){
            unlink($seoPath);
        }

    }

}
